﻿namespace GameObjectsLib.Players
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Linq;
    using GameMap;
    using ProtoBuf;
    using Region = GameMap.Region;

    /// <summary>
    ///     Instance of this class represents template for player in the game.
    /// </summary>
    [Serializable]
    [ProtoContract]
    [ProtoInclude(400, typeof(AiPlayer))]
    [ProtoInclude(401, typeof(HumanPlayer))]
    public abstract class Player : IEquatable<Player>
    {
        protected Player()
        {
        }

        public virtual int Id
        {
            get { return (int) Color; }
        }

        public abstract string Name { get; }

        [ProtoMember(1)]
        public KnownColor Color { get; }

        /// <summary>
        ///     Regions this player controls.
        /// </summary>
        public IReadOnlyList<Region> ControlledRegions
        {
            get { return ControlledRegionsInternal; }
        }

        [ProtoMember(2, AsReference = true)]
        internal List<Region> ControlledRegionsInternal { get; } = new List<Region>();

        public const int BasicIncome = 5;

        /// <summary>
        ///     Calculates players army income and returns it.
        /// </summary>
        /// <returns>Army income of the player.</returns>
        public int GetIncome()
        {
            IEnumerable<SuperRegion> superRegionsOwned = (from region in ControlledRegions
                                                          select region.SuperRegion
                                                          into superRegion
                                                          where superRegion.Owner == this
                                                          select superRegion).Distinct();
            return BasicIncome + superRegionsOwned.Sum(superRegion => superRegion.Bonus);
        }

        protected Player(KnownColor color)
        {
            Color = color;
        }

        public override string ToString()
        {
            return Name;
        }

        /// <summary>
        /// Reports whether given region is owned by
        /// this instance of a player.
        /// </summary>
        /// <param name="region"></param>
        /// <returns></returns>
        public bool IsRegionMine(Region region)
        {
            return region.Owner == this;
        }

        public bool Equals(Player other)
        {
            if (ReferenceEquals(null, other))
            {
                return false;
            }
            if (ReferenceEquals(this, other))
            {
                return true;
            }
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj))
            {
                return false;
            }
            if (ReferenceEquals(this, obj))
            {
                return true;
            }
            if (obj.GetType() != GetType())
            {
                return false;
            }
            return Equals((Player) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return ((int) Color * 397) ^ (ControlledRegions != null ? ControlledRegions.GetHashCode() : 0);
            }
        }

        public static bool operator ==(Player left, Player right)
        {
            if (ReferenceEquals(left, null))
            {
                return ReferenceEquals(right, null);
            }
            return left.Equals(right);
        }

        public static bool operator !=(Player left, Player right)
        {
            return !(left == right);
        }
    }
}
