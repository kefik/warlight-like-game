﻿namespace Communication.CommandHandling.Tokens.SetupMap
{
    using Shared;

    public interface ISetupMapToken : ICommandToken
    {
    }
}