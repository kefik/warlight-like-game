﻿namespace GameAi.Data.GameRecording
{
    using System.Collections.Generic;

    public class BotRound
    {
        public IList<BotTurn> BotTurns { get; set; }
    }
}