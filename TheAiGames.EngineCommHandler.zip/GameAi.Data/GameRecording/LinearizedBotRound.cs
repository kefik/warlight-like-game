﻿namespace GameAi.Data.GameRecording
{
    public abstract class LinearizedBotRound
    {
        
    }
}